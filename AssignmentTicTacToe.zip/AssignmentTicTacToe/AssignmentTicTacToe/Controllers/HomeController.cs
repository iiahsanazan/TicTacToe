﻿using AssignmentTicTacToe.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace AssignmentTicTacToe.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ViewResult Initial()
        {
            HttpContext.Session.Clear();

            return View();
        }
        [HttpGet]
        public ViewResult Index(int boardSize)
        {
           
            TempData["Size"] = boardSize;
            GameSession session = new GameSession(HttpContext.Session);
            Game game = session.GetGame(boardSize);
            session.SetGame(game);
            return View(game);
        }

        [HttpPost]
        public RedirectToActionResult NewGame()
        {
            GameSession session = new GameSession(HttpContext.Session);
            Game game = session.GetGame(Convert.ToInt32(TempData["Size"]));

            game.NewGame();
            session.SetGame(game);

            return RedirectToAction("Index");
        }

        [HttpPost]
        public RedirectToActionResult HandleClickOnSquare(int id)
        {
           
            GameSession session = new GameSession(HttpContext.Session);
            Game game = session.GetGame(Convert.ToInt32(TempData["Size"]));
            if ((game.BoxValues[id] != "") || (game.IsGameOver))
            {
                return RedirectToAction("Index");
            }
            game.UpdateSquare(id);
            game.DetermineIfGameIsWon();
            if (!game.IsGameOver) { game.ChangePlayer(); }
            session.SetGame(game);

            return RedirectToAction("Index");
        }

    }
}