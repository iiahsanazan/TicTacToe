﻿namespace AssignmentTicTacToe.Models
{
    public class GameSession
    {
        private ISession session;

        private const string GameKey = "ticTacToe";

        public GameSession(ISession session)
        {
            this.session = session;
        }

        public void SetGame(Game game)
        {
            session.SetObject(GameKey, game);
        }

        public Game GetGame(int size)
        {
            return session.GetObject<Game>(GameKey) ?? new Game(size);
        }
    }
}
