﻿namespace AssignmentTicTacToe.Models
{
    public class Player
    {
        public string Name { get; set; }
        public string Mark { get; set; }
    }
}
