﻿namespace AssignmentTicTacToe.Models
{
    public class Game
    {
         public Player Player1 { get; set; }
        public Player Player2 { get; set; }
        public string[] BoxValues { get; set; }
        public int BoardSize { get;  set; }
        public string CurrentPlayerName { get; set; }

        public Player CurrentPlayer()
        {
            if (Player1.Name == CurrentPlayerName)
            {
                return Player1;
            }
            else
            {
                return Player2;
            }
        }

        public bool IsGameOver;

        public bool IsATie;

        public Game(int boardSize)
        {
            BoardSize = boardSize;
            NewGame();
        }

        public void NewGame()
        {
            Player1 = new Player { Name = "X", Mark = "X" };
            Player2 = new Player { Name = "O", Mark = "O" };

            CurrentPlayerName = Player1.Name;
            BoxValues = new string[BoardSize * BoardSize];
            for (int i = 0; i < BoxValues.Length; i++)
            {   
                BoxValues[i] = "";
            }
            IsGameOver = false;
            IsATie = false;
        }

        public void UpdateSquare(int id)
        {
            BoxValues[id] = CurrentPlayer().Mark;
        }

        public void ChangePlayer()
        {
            if (CurrentPlayerName == Player1.Name)
            {
                CurrentPlayerName = Player2.Name;
            }
            else
            {
                CurrentPlayerName = Player1.Name;
            }
        }

        public void DetermineIfGameIsWon()
        {
            string m = CurrentPlayer().Mark;

           
            for (int i = 0; i < BoardSize; i++)
            {
                bool rowWin = true;
                for (int j = 0; j < BoardSize; j++)
                {
                    if (BoxValues[i * BoardSize + j] != m)
                    {
                        rowWin = false;
                        break;
                    }
                }
                if (rowWin)
                {
                    IsGameOver = true;
                    return;
                }
            }

           
            for (int i = 0; i < BoardSize; i++)
            {
                bool colWin = true;
                for (int j = 0; j < BoardSize; j++)
                {
                    if (BoxValues[j * BoardSize + i] != m)
                    {
                        colWin = false;
                        break;
                    }
                }
                if (colWin)
                {
                    IsGameOver = true;
                    return;
                }
            }

            
            bool mainDiagonalWin = true;
            for (int i = 0; i < BoardSize; i++)
            {
                if (BoxValues[i * BoardSize + i] != m)
                {
                    mainDiagonalWin = false;
                    break;
                }
            }
            if (mainDiagonalWin)
            {
                IsGameOver = true;
                return;
            }

        
            bool antiDiagonalWin = true;
            for (int i = 0; i < BoardSize; i++)
            {
                if (BoxValues[(BoardSize - 1 - i) * BoardSize + i] != m)
                {
                    antiDiagonalWin = false;
                    break;
                }
            }
            if (antiDiagonalWin)
            {
                IsGameOver = true;
                return;
            }

         
            if (BoxValues.All(x => !string.IsNullOrEmpty(x)))
            {
                IsGameOver = true;
                IsATie = true;
            }
        }

    }
}

